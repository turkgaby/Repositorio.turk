# SportsDevil_JX
This is an unofficial SportsDevil fork by JairoX. It is mainly based on Hubbab3's version but includes some additional sites. I try to provide updates and fixes as needed, though I only check those sites I watch myself. 

Note that SportsDevil only accesses streams from sites that charge for the viewing of their streams through web banner advertising. SportsDevil is intended for those who have clicked on endless ads but cannot access the stream due to faulty web site setup. **SportsDevil does not provide any streams of its own; stream quality, content and copyright are responsibility of the ad-financed source web site.**

If you install via zip file and don't want this fork to be overwritten by a repos, I recommend to disable SD autoupdate.

For information on current development and maintenance status, pls check the tvaddons forum.
